# Nixie tube Clock.

#这个网页特别设计了一套手工数字字体家族，包括Nixiebold、Nixiemini、Nixieslim和Nixieregular，无需图片即可无缝运行。
为了模仿Nixie电子管的显示效果，我遵循了Nixie数字的独特顺序：5 6 7 4 3 8 9 2 0 1，并在数字前面添加了网格，以实现真实的感觉。
此外，设计中还加入了一个计时器。你可以通过简单的点击或使用空格键轻松激活它。有趣的是，我从未见过计时器在0.111以下 - 也许你将是第一个做到这一点的人！享受探索这个独特的数字体验。


#Featuring a handmade number font family that includes Nixiebold, Nixiemini, Nixieslim, and Nixieregular, this webpage is designed to function seamlessly without the need for images.
In an attempt to emulate the display of a Nixie tube, I’ve followed the unique order of the Nixie numbers: 5 6 7 4 3 8 9 2 0 1, and added a mesh in front of the numbers for an authentic feel.
Additionally, a timer has been incorporated into the design. You can easily activate it with a simple click or by using the space bar. Interestingly, I’ve never seen the timer drop below 0.111 - perhaps you’ll be the first to do it! Enjoy exploring this unique digital experience.


我们新增了两个功能丰富的页面。在"倒计时"页面，你可以设定未来的某一刻，启动倒计时，或者你也可以直接点击预设的时间按钮开始倒计时。在"时间计算器"页面，你可以设定过去的某一刻，计算从那一刻到现在经过的时间，无论是初次相遇的时刻，还是某个重要事件的发生时刻。在这两个页面中，你的五个最近的数据会被保存在你的本地电脑中，你只需直接点击这些数据，就可以开始计时。此外，你还可以将喜欢的图片拖拽到浏览器窗口，设定为网页的背景，让你的体验更加个性化和愉悦。希望你会喜欢这些新的功能！


Two new pages have been added. In the countdown page, you can set a future time for the countdown, or you can directly click the specific time button to start the countdown. In the Time calculator page, you can set a past time for calculation, calculating the time from the first encounter or event occurrence to the present. On the page, five pieces of data will be saved to your local computer, and you can start timing by directly clicking on the data. At the same time, you can also drag your favorite picture into the window to become the background of the webpage.


如果你有任何问题或需要帮助，不要犹豫，尽管联系我。享受你的访问。我非常珍视你的意见和专业知识。你的支持对我来说意义重大，将极大地促进我的工作。希望你能喜欢这个网站！
If you have any questions or need assistance, don’t hesitate to reach out. Enjoy you visit.I truly value your opinion and expertise. Your support would mean a lot to me and would greatly contribute to my work.
#https://aj300542.github.io/nixietube/
