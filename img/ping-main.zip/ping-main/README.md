# ping
用JS实现数字乒乓球剧团。时间都被我打出来了。

https://aj300542.github.io/ping/
