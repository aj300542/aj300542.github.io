let poems = [];
let selectedChunks = [];
let hintTimer = null;
let score = 0;
let comboCount = 0;
let maxCombo = 0;
let matchedLines = {};

// 解析诗词文本
function parsePoems(txt) {
    const sections = txt.split('---');
    return sections.map(section => {
        const lines = section.trim().split('\n');
        const title = lines[0]?.replace('标题：', '').trim();
        const author = lines[1]?.replace('作者：', '').trim();
        const content = lines[2]?.replace('正文：', '').trim();
        return { title, author, content };
    }).filter(poem => poem.title && poem.author && poem.content);
}

// 抽取并打乱有效词组
function extractValidGroups(poems, mumex = 5) {
    const selected = poems.sort(() => 0.5 - Math.random()).slice(0, mumex);
    let groupChunks = [];

    selected.forEach(poem => {
        const lines = poem.content.replace(/，|。|！|？|；/g, '｜').split('｜').filter(Boolean);
        lines.forEach(line => {
            const chars = [...line.trim()];
            let parts = [];

            if (chars.length === 5) {
                parts = [chars.slice(0, 2).join(''), chars.slice(2).join('')];
            } else if (chars.length === 7) {
                parts = [
                    chars.slice(0, 2).join(''),
                    chars.slice(2, 4).join(''),
                    chars.slice(4).join('')
                ];
            }

            if (parts.length >= 2) {
                const groupID = `${poem.title}-${line}`;
                parts.forEach(part => {
                    groupChunks.push({ text: part, group: groupID });
                });
            }
        });
    });

    return groupChunks.sort(() => 0.5 - Math.random());
}

// 检查每组是否完整
function verifyGroupCompleteness(chunks) {
    const grouped = {};
    chunks.forEach(({ text, group }) => {
        grouped[group] = grouped[group] || [];
        grouped[group].push(text);
    });

    const results = {};
    Object.keys(grouped).forEach(group => {
        results[group] = {
            count: grouped[group].length,
            isComplete: grouped[group].length >= 2,
            words: grouped[group]
        };
    });

    return results;
}

// 渲染词块卡片
function renderChunks(chunks) {
    const container = document.getElementById('chunks-container');
    container.innerHTML = '';
    selectedChunks = [];

    chunks.forEach(({ text, group }, index) => {
        const card = document.createElement('div');
        card.className = 'chunk-card';
        card.textContent = text;
        card.dataset.group = group;
        card.dataset.index = index;

        // ✨ 拖拽功能初始化
        card.setAttribute('draggable', true);
        card.addEventListener('dragstart', e => {
            e.dataTransfer.setData('text/plain', card.dataset.group + ',' + card.dataset.index);
        });

        card.addEventListener('click', () => {
            if (card.classList.contains('matched') || selectedChunks.includes(card)) return;

            card.classList.add('selected');
            selectedChunks.push(card);
            clearTimeout(hintTimer);

            if (selectedChunks.length === 2) {
                const [a, b] = selectedChunks;
                const isMatch = a.dataset.group === b.dataset.group;

                if (isMatch) {
                    a.classList.add('matched');
                    b.classList.add('matched');
                    matchEntireGroup(a.dataset.group);
                    revealMatchedLine(a.dataset.group);
                    checkCompletionStatus();

                    comboCount++;
                    score += 1 * comboMultiplier(comboCount);
                    maxCombo = Math.max(maxCombo, comboCount);
                    updateScoreDisplay();
                } else {
                    a.classList.add('error');
                    b.classList.add('error');
                    comboCount = 0;
                    updateScoreDisplay();
                }

                setTimeout(() => {
                    a.classList.remove('selected', 'error');
                    b.classList.remove('selected', 'error');
                    selectedChunks = [];
                }, 1000);
            } else {
                hintTimer = setTimeout(() => showHintPair(window.currentChunks), 2000);
            }
        });
        // 🧲 拖拽开始：记录拖动卡片的信息
        card.setAttribute('draggable', true);
        card.addEventListener('dragstart', e => {
            e.dataTransfer.setData('text/plain', card.dataset.group + ',' + card.dataset.index);
        });

        // 🧲 拖拽悬停：允许放置
        card.addEventListener('dragover', e => {
            e.preventDefault(); // 必须阻止默认以允许 drop
        });

        // 🧩 拖拽放置：配对逻辑判断
        card.addEventListener('drop', e => {
            const [groupA, indexA] = e.dataTransfer.getData('text/plain').split(',');
            const groupB = card.dataset.group;

            if (groupA === groupB && indexA === card.dataset.index) return; // 防止拖到自己

            if (groupA === groupB) {
                // ✅ 配对成功
                card.classList.add('matched');
                const draggedCard = document.querySelector(`.chunk-card[data-group="${groupA}"][data-index="${indexA}"]`);
                draggedCard.classList.add('matched');

                matchEntireGroup(groupA);
                revealMatchedLine(groupA);
                checkCompletionStatus();
                comboCount++;
                score += 1 * comboMultiplier(comboCount);
                maxCombo = Math.max(maxCombo, comboCount);
                updateScoreDisplay();
            } else {
                // ❌ 配对失败
                card.classList.add('error');
                setTimeout(() => card.classList.remove('error'), 1000);
            }
        });

        container.appendChild(card);
    });
}

// 匹配整组（处理剩余部分）
function matchEntireGroup(groupID) {
    const cards = document.querySelectorAll('.chunk-card');
    cards.forEach(card => {
        if (card.dataset.group === groupID && !card.classList.contains('matched')) {
            card.classList.add('matched');
            card.classList.remove('selected', 'error');
            card.style.backgroundColor = '#d0f0c0';
        }
    });
}

// 显示已配对的诗句（按原顺序）
function revealMatchedLine(groupID) {
    const [poemTitle, line] = groupID.split('-');
    const poemData = poems.find(p => p.title === poemTitle);
    const author = poemData?.author || '';

    const slots = document.querySelectorAll('.poem-slot');
    let target = Array.from(slots).find(div => div.dataset.poem === poemTitle);

    if (!target) {
        target = Array.from(slots).find(div => !div.dataset.poem);
        if (target) target.dataset.poem = poemTitle;
    }

    if (target) {
        target.dataset.poem = poemTitle;

        if (!target.querySelector('.poem-title')) {
            target.innerHTML = '';
            const titleEl = document.createElement('div');
            titleEl.className = 'poem-title';
            titleEl.textContent = poemTitle;
            const authorEl = document.createElement('div');
            authorEl.className = 'poem-author';
            authorEl.textContent = `（${author}）`;
            target.appendChild(titleEl);
            target.appendChild(authorEl);
        }

        matchedLines[poemTitle] = matchedLines[poemTitle] || new Set();
        matchedLines[poemTitle].add(line);

        const originalLines = poemData.content.replace(/，|。|！|？|；/g, '｜').split('｜').filter(Boolean);
        target.querySelectorAll('.poem-line').forEach(el => el.remove());

        originalLines.forEach(l => {
            if (matchedLines[poemTitle].has(l)) {
                const lineEl = document.createElement('div');
                lineEl.className = 'poem-line';
                lineEl.textContent = `「${l}」`;
                target.appendChild(lineEl);
            }
        });
    }

    setTimeout(() => showHintPair(window.currentChunks), 800);
}

// 显示提示词组
function showHintPair(chunks) {
    const activeChunks = chunks.filter(({ text, group }, index) => {
        const card = Array.from(document.querySelectorAll('.chunk-card'))
            .find(el => el.textContent === text && el.dataset.group === group && el.dataset.index == index);
        return card && !card.classList.contains('matched');
    });

    const grouped = {};
    activeChunks.forEach(({ text, group }) => {
        grouped[group] = grouped[group] || [];
        grouped[group].push(text);
    });

    for (let group in grouped) {
        if (grouped[group].length >= 2) {
            const [word1, word2] = grouped[group].slice(0, 2);
            const hintBox = document.getElementById('hint-box');
            hintBox.textContent = `提示：${word1} ➜ ${word2}`;
            hintBox.classList.add('show');
            setTimeout(() => hintBox.classList.remove('show'), 2500);

            const allCards = document.querySelectorAll('.chunk-card');
            allCards.forEach(card => {
                if ((card.textContent === word1 || card.textContent === word2) && !card.classList.contains('matched')) {
                    flashHint(card);
                }
            });
            break;
        }
    }
}

// 闪烁动画触发器
function flashHint(card) {
    card.classList.remove('hint');
    void card.offsetWidth;
    card.classList.add('hint');
}

// 检查是否全部完成
function checkCompletionStatus() {
    const allCards = document.querySelectorAll('.chunk-card');
    const allMatched = Array.from(allCards).every(card => card.classList.contains('matched'));

    if (allMatched && allCards.length > 0) {
        const msg = document.getElementById('completion-message');
        msg.classList.add('show');
        setTimeout(() => msg.classList.remove('show'), 5000);
    }
}

// 分数加成规则
function comboMultiplier(count) {
    if (count >= 5) return 3;
    if (count >= 3) return 2;
    return 1;
}

// 更新分数显示
function updateScoreDisplay() {
    document.getElementById('score').textContent = `得分：${score}`;
    document.getElementById('combo').textContent = `连击：${comboCount}`;
}

// 主逻辑入口（解析 + 筛选 + 渲染）
function verifyAndRender(poems, mumex = 5) {
    const fullChunks = extractValidGroups(poems, mumex);
    const completeness = verifyGroupCompleteness(fullChunks);
    const validGroups = Object.entries(completeness)
        .filter(([_, info]) => info.isComplete)
        .map(([group]) => group);

    const filteredChunks = fullChunks.filter(({ group }) => validGroups.includes(group));
    renderChunks(filteredChunks);

    const groupCount = {};
    filteredChunks.forEach(({ group }) => {
        groupCount[group] = (groupCount[group] || 0) + 1;
    });
    console.table(groupCount);

    // 保存当前词块供提示使用
    window.currentChunks = filteredChunks;
}

// 手动输入匹配
function manualMatchPoemLine() {
    const input = document.getElementById('manual-input').value
        .trim()
        .replace(/[\s\u200B\u200C\u200D]/g, '')
        .normalize('NFC');
    if (!input) return;

    const chunkCards = Array.from(document.querySelectorAll('.chunk-card'))
        .filter(card => !card.classList.contains('matched'));

    const groupedByPoem = {};
    chunkCards.forEach(card => {
        const group = card.dataset.group;
        groupedByPoem[group] = groupedByPoem[group] || [];
        groupedByPoem[group].push(card);
    });

    for (let group in groupedByPoem) {
        const chunks = groupedByPoem[group].map(c => c.textContent);
        const matchCount = chunks.filter(chunk => input.includes(chunk)).length;

        // ✅ 只要输入中出现了两个或以上 chunk，就判定为匹配成功
        if (matchCount >= 2) {
            groupedByPoem[group].forEach(card => {
                card.classList.add('matched');
                card.style.backgroundColor = '#d0f0c0';
            });

            matchEntireGroup(group);
            revealMatchedLine(group);
            checkCompletionStatus();
            break;
        }
    }
}


// 初始化加载诗词数据 + 设置交互
fetch('abc.txt')
    .then(res => res.text())
    .then(txt => {
        poems = parsePoems(txt);
        verifyAndRender(poems, 5);

        document.getElementById('refresh-chunks').addEventListener('click', () => {
            verifyAndRender(poems, 5);
        });

        const inputBox = document.getElementById('manual-input');
        if (inputBox) {
            inputBox.addEventListener('input', () => {
                manualMatchPoemLine();
            });
        }
    });
