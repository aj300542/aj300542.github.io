# led
ledTxt 像素文字模拟器
看完罗小黑战记2，好可爱的猫咪丫。画了就加入了罗小黑头像，txt内容换成了罗小黑战记里面的经典台词。
 https://aj300542.github.io/led/
